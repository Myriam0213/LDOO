/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Liliana y Irenia
 */
public class Db_Connection {
    public Connection Connection() throws SQLException{
    String dbURI = "jdbc:derby://localhost:1527/Comentarios";
    String username = "fcfm";
    String password = "lsti01";
    Connection conexion = DriverManager.getConnection(dbURI, username, password);
    return conexion;
    }
}
